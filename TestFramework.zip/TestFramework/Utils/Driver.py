from selenium import webdriver


def get_driver():
    opts = webdriver.ChromeOptions()
    opts.set_capability("platform", "LINUX")
    opts.set_capability("browserName", "chrome")
    #   options.add_experimental_option("profile_default_content_setting_values.media_stream_mic", 1)
    #   options.add_experimental_option("profile_default_content_setting_values.geolocation", 1)
    #   options.add_experimental_option("profile_default_content_setting_values.media_stream_camera", 1)
    #   options.add_experimental_option("profile_default_content_setting_values.notifications", 1)
    prefs = {'profile.default_content_setting_values.media_stream_mic': 1,
             'profile.default_content_setting_values.geolocation': 1,
             'profile.default_content_setting_values.media_stream_camera': 1,
             'profile.default_content_setting_values.notifications': 1}
    opts.add_experimental_option("prefs", prefs)
    opts.add_argument("--use-fake-device-for-media-stream")
    opts.add_argument("use-file-for-fake-video-capture=/home/seluser/vdos/test.y4m")
    web_driver = webdriver.Remote(command_executor="http://localhost:4444/wd/hub", options=opts)
    # web_driver = webdriver.Chrome(executable_path="C:\\Users\\Atul\\PycharmProjects\\SeleniumFrameworkPOM
    # \\BrowserDrivers\\chromedriver.exe", options=options)
    return web_driver
