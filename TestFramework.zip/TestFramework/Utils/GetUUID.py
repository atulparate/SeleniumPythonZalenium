import requests
from Config import Constants
from jsonpath_ng import jsonpath, parse
import re


def get_uuid(sessionID, authKey):
    api_url = Constants.activities_url + sessionID
    headers_list = {'Content-type': 'application/json', 'Accept': '*/*', 'Authorization': authKey}
    r = requests.get(url=api_url, headers=headers_list, timeout=(10, 20))
    print("status code =" + str(r.status_code))

    json_expression = parse("$[2].data")

    for match in json_expression.find(r.json()):
        match.value

    regex = 'id=(.*?)"'
    uuid = re.search(regex, str(match.value))
    return uuid[0][3:11]
