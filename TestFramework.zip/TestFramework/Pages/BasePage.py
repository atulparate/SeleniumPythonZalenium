from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec


class BasePage:
    def __init__(self, driver):
        self.driver = driver

    def navigate(self, url):
        self.driver.get(url)

    def do_click(self, by_locator):
        WebDriverWait(self.driver, 10).until(ec.visibility_of_element_located(by_locator)).click()

    def is_element_displayed(self, by_locator):
        element = WebDriverWait(self.driver, 10).until(ec.visibility_of_element_located(by_locator))
        return bool(element)

    def enter_text(self, by_locator, text_to_enter):
        WebDriverWait(self.driver, 10).until(ec.visibility_of_element_located(by_locator)).send_keys(text_to_enter)

    def get_browser_windows(self):
        return self.driver.window_handles

    def switch_to_window(self, window_index):
        return self.driver.switch_to_window(self.driver.window_handles[window_index])

    def launch_app_new_window(self, app_url):
        self.driver.execute_script("window.open('" + app_url + "');")
