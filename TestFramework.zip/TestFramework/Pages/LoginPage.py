from selenium.webdriver.common.by import By
from Pages.BasePage import BasePage
from Config import Constants


class LoginPage(BasePage):
    elem_UserName = (By.ID, "email")
    elem_Password = (By.ID, "password")
    elem_Login = (By.ID, "login")

    def __init__(self, driver):
        super().__init__(driver)
        self.driver.get(Constants.app_url)

    def login_to_app(self):
        # self.navigate()
        self.enter_text(self.elem_UserName, "auto_operator")
        self.enter_text(self.elem_Password, "Password@1")
        self.do_click(self.elem_Login)

