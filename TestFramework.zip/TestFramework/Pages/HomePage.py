from Pages.BasePage import BasePage
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as ec


class HomePage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    elem_Email = (By.CSS_SELECTOR, ".row.display-list input[type='text']")
    elem_Reference = (By.CSS_SELECTOR, ".input-group>input")
    elem_SendLink = (By.CSS_SELECTOR, "button[type='submit']")
    elem_TwoWayAudioVideo = (By.XPATH, "//label[@class='switch']/span[@class='switch-slider round']")
    elem_AddStream = (By.ID, "addStream")

    def enter_stream_details(self, textEmailId, txtReference):
        if bool(self.is_element_displayed(self.elem_Email)):
            self.enter_text(self.elem_Email, textEmailId)
            self.enter_text(self.elem_Reference, txtReference)
            self.do_click(self.elem_TwoWayAudioVideo)

    def send_streaming_link(self):
        if bool(self.is_element_displayed(self.elem_SendLink)):
            self.do_click(self.elem_SendLink)

    def get_session_id(self):
        if bool(self.is_element_displayed(self.elem_AddStream)):
            sessionId = self.driver.execute_script("return sessionStorage.sessionId")
            print(sessionId)
        return sessionId

    def get_auth_key(self):
        authKey = self.driver.execute_script("return sessionStorage.cred")
        print(authKey)
        return authKey
