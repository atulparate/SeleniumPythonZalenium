from selenium.webdriver.common.by import By
from Pages.BasePage import BasePage
from Config import Constants

class StreamingPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)

    elem_StartVideo = (By.CSS_SELECTOR, "#home-buttons ,button.startStreamButton")
    elem_TakePhoto = (By.CSS_SELECTOR, "#home-buttons .button.takePhotoButton")
    elem_StopVideo = (By.CSS_SELECTOR, ".stop-video-btn")

    def is_stop_video_visible(self):
        self.is_element_displayed(self, self.elem_StopVideo)

    def launch_streaming_url(self, url):
        self.driver.execute_script("window.open('"+url+"')")

    def start_streaming(self):
        if bool(self.is_element_displayed(self.elem_StartVideo)):
            self.driver.execute_script("startStream()")
        self.driver.execute_script("startStream()")

    def stop_streaming(self):
        if bool(self.is_element_displayed()):
            self.driver.execute_script("stopStream()")
            self.driver.execute_script("finish()")
            self.driver.execute_script("showSessionEndScreen()")




