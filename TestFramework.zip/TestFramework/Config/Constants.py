app_url = "https://autoqatest.eye999.co.uk/eye/login"
target_email = "atul.parate@capita.co.uk"
reference_text = "Automation Testing"

partial_streaming_url = "https://autoqatest.eye999.co.uk/eye/c.html?id="
activities_url = "https://autoqatest.eye999.co.uk/eye-service/resource/activities?session-id="
