import pytest
from Utils import Driver
from selenium import webdriver


# from webdrivermanager.chrome import ChromeDriverManager


@pytest.fixture(scope='function')
def init_driver(request):
    opts = webdriver.ChromeOptions()
    opts.set_capability("platform", "LINUX")
    opts.set_capability("browserName", "chrome")
    prefs1 = {'profile.default_content_setting_values.media_stream_mic': 1,
              'profile.default_content_setting_values.geolocation': 1,
              'profile.default_content_setting_values.media_stream_camera': 1,
              'profile.default_content_setting_values.notifications': 1}
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--use-fake-device-for-media-stream")
    opts.add_argument("--use-file-for-fake-video-capture=/home/seluser/vdos/test.y4m")
    opts.add_experimental_option("prefs", prefs1)
    web_driver = webdriver.Remote(command_executor="http://localhost:4444/wd/hub", options=opts)
    web_driver.implicitly_wait(10)
    request.cls.driver = web_driver
    yield
    # web_driver.close()
