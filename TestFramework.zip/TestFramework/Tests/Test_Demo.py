from Pages.LoginPage import LoginPage
from Pages.HomePage import HomePage
from Pages.StreamingPage import StreamingPage
from Config import Constants
import time
from Utils import GetUUID

from Tests.Test_Base import BaseTest


class TestDemo(BaseTest):

    def test_login(self):
        session_count = 3
        operator_start_index = 1

        uuids = []

        self.login_page = LoginPage(self.driver)
        self.home_page = HomePage(self.driver)
        self.video_streaming = StreamingPage(self.driver)

        for iterator in range(session_count):
            if iterator != 0:
                self.login_page.launch_app_new_window(Constants.app_url)
                self.login_page.switch_to_window(iterator)
            self.login_page.login_to_app()
            self.home_page.enter_stream_details(Constants.target_email, Constants.reference_text)
            self.home_page.send_streaming_link()
            uuids.append(GetUUID.get_uuid(self.home_page.get_session_id(), self.home_page.get_auth_key()))

        print(uuids)
        operator_browsers = len(self.home_page.get_browser_windows())
        operator_end_index = operator_browsers
        caller_start_index = operator_end_index

        for uuid in uuids:
            self.video_streaming.launch_streaming_url(Constants.partial_streaming_url + uuid)

        caller_end_index = caller_start_index + len(uuids)

        for iterator in range(caller_start_index, caller_end_index):  # range(2, 4):  #
            print("hi -- " + str(iterator))
            self.home_page.switch_to_window(iterator)
            self.video_streaming.start_streaming()
            time.sleep(10)
            #   self.video_streaming.stop_streaming()

    def test_login1(self):
        session_count = 3
        operator_start_index = 1

        uuids = []

        self.login_page = LoginPage(self.driver)
        self.home_page = HomePage(self.driver)
        self.video_streaming = StreamingPage(self.driver)

        for iterator in range(session_count):
            if iterator != 0:
                self.login_page.launch_app_new_window(Constants.app_url)
                self.login_page.switch_to_window(iterator)
            self.login_page.login_to_app()
            self.home_page.enter_stream_details(Constants.target_email, Constants.reference_text)
            self.home_page.send_streaming_link()
            uuids.append(GetUUID.get_uuid(self.home_page.get_session_id(), self.home_page.get_auth_key()))

        print(uuids)
        operator_browsers = len(self.home_page.get_browser_windows())
        operator_end_index = operator_browsers
        caller_start_index = operator_end_index

        for uuid in uuids:
            self.video_streaming.launch_streaming_url(Constants.partial_streaming_url + uuid)

        caller_end_index = caller_start_index + len(uuids)

        for iterator in range(caller_start_index, caller_end_index):  # range(2, 4):  #
            print("hi -- " + str(iterator))
            self.home_page.switch_to_window(iterator)
            self.video_streaming.start_streaming()
            time.sleep(10)
            #   self.video_streaming.stop_streaming()

    def test_login3(self):
        session_count = 3
        operator_start_index = 1

        uuids = []

        self.login_page = LoginPage(self.driver)
        self.home_page = HomePage(self.driver)
        self.video_streaming = StreamingPage(self.driver)

        for iterator in range(session_count):
            if iterator != 0:
                self.login_page.launch_app_new_window(Constants.app_url)
                self.login_page.switch_to_window(iterator)
            self.login_page.login_to_app()
            self.home_page.enter_stream_details(Constants.target_email, Constants.reference_text)
            self.home_page.send_streaming_link()
            uuids.append(GetUUID.get_uuid(self.home_page.get_session_id(), self.home_page.get_auth_key()))

        print(uuids)
        operator_browsers = len(self.home_page.get_browser_windows())
        operator_end_index = operator_browsers
        caller_start_index = operator_end_index

        for uuid in uuids:
            self.video_streaming.launch_streaming_url(Constants.partial_streaming_url + uuid)

        caller_end_index = caller_start_index + len(uuids)

        for iterator in range(caller_start_index, caller_end_index): #  range(2, 4):  #
            print("hi -- " + str(iterator))
            self.home_page.switch_to_window(iterator)
            self.video_streaming.start_streaming()
            time.sleep(10)
            #   self.video_streaming.stop_streaming()

    def test_login4(self):
        session_count = 3
        operator_start_index = 1

        uuids = []

        self.login_page = LoginPage(self.driver)
        self.home_page = HomePage(self.driver)
        self.video_streaming = StreamingPage(self.driver)

        for iterator in range(session_count):
            if iterator != 0:
                self.login_page.launch_app_new_window(Constants.app_url)
                self.login_page.switch_to_window(iterator)
            self.login_page.login_to_app()
            self.home_page.enter_stream_details(Constants.target_email, Constants.reference_text)
            self.home_page.send_streaming_link()
            uuids.append(GetUUID.get_uuid(self.home_page.get_session_id(), self.home_page.get_auth_key()))

        print(uuids)
        operator_browsers = len(self.home_page.get_browser_windows())
        operator_end_index = operator_browsers
        caller_start_index = operator_end_index

        for uuid in uuids:
            self.video_streaming.launch_streaming_url(Constants.partial_streaming_url + uuid)

        caller_end_index = caller_start_index + len(uuids)

        for iterator in range(caller_start_index, caller_end_index): #  range(2, 4):  #
            print("hi -- " + str(iterator))
            self.home_page.switch_to_window(iterator)
            self.video_streaming.start_streaming()
            time.sleep(10)
            #   self.video_streaming.stop_streaming()